function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6boS86qsO28":
        Script1();
        break;
  }
}

function Script1()
{
  window.opener.location.reload();
window.close();
}

