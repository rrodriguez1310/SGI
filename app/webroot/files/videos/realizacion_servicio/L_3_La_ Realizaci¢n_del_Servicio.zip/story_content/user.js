function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5oiyMQZm31c":
        Script1();
        break;
  }
}

function Script1()
{
  window.opener.location.reload();
window.close();
}

