function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6V2ETJN7WKF":
        Script1();
        break;
  }
}

function Script1()
{
  window.opener.location.reload();
window.close();
}

