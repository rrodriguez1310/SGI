function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6cbizZOAF3d":
        Script1();
        break;
  }
}

function Script1()
{
  window.opener.location.reload();
window.close();
}

